import numpy as np
from PIL import Image

!unzip '/content/Fingerprintdataset.zip'

import keras
from keras.datasets import mnist
from keras.models import Sequential
from keras.layers import Dense, Dropout, Flatten
from keras.layers import Conv2D, MaxPooling2D
from google.colab.patches import cv2_imshow

num_classes=9
epochs=2

model = Sequential()

model.add(Conv2D(64, kernel_size=(3, 3),
                 activation='relu',
                 input_shape=(30,30,3)))
model.add(MaxPooling2D(pool_size=(2, 2)))
#model.add(Dropout(0.25))

model.add(Conv2D(32, (3, 3), activation='relu'))
model.add(MaxPooling2D(pool_size=(2, 2)))
#model.add(Dropout(0.25))

model.add(Flatten())
model.add(Dense(128, activation='relu'))
#model.add(Dropout(0.5))

model.add(Dense(num_classes, activation='softmax'))

model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])

from keras.preprocessing.image import ImageDataGenerator

train_datagen= ImageDataGenerator(rescale=1/255,shear_range=0.2,zoom_range=0.2,horizontal_flip=True)

batchSize=1

training_set=train_datagen.flow_from_directory('/content/Fingerprintdataset/training_set',
                                               target_size=(30,30),
                                               batch_size=batchSize,
                                               class_mode='categorical')
no_of_steps_per_epoch_training=20

model.fit_generator(training_set,steps_per_epoch=no_of_steps_per_epoch_training,epochs=1)

model_json = model.to_json()
with open("model.json","w") as json_file:
       json_file.write(model_json)
model.save_weights("model.h5")