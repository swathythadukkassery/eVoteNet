Evote NET:It is a website in which the fingerprint of a voter is uploaded and the same is compared with the fingerprint from the aadhar database and ensures that the person is not a fake.
The prediction is done with the help of CNN Model.The model provided an accuracy of 95 percent which shows o
# keras

Keras is an Open Source Neural Network library written in Python .

## Installation

Use the package manager pip to install keras.

	pip install --upgrade tensorflow
	pip install keras


# django

Django is a free and open source web application framework written in Python.

## Installation

Use the package manager pip to install django.

	pip install django

# The html file (Website) is present in the template folder




	